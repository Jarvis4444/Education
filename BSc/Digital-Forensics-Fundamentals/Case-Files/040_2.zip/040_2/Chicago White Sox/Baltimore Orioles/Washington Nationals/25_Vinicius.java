// Template: Finding highest, lowest in a foreach numeric array.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example215App extends Object
{
	private static final String  CONSTANT_1 = "Attack 4 Port=53";
	private static final String HASH_REFERENCE = "a5383cbf6191338a7ddb948bb8e0dd0c";

	public static void main(String[] argStrings) throws Exception
	{
		int[] timesInSeconds = {834, 327, 455, 181, 104, 52};
		
		int highest = 0;
		int lowest = 0;
		
		for (int timeInSeconds: timesInSeconds)
		{
			System.out.println("timeInSeconds: " + timeInSeconds);
		
			if (timeInSeconds > highest)
			{
				System.out.println("New highest: " + timeInSeconds);
				highest = timeInSeconds;
			}
		
			if (timeInSeconds < lowest)
			{
				lowest = timeInSeconds;
				System.out.println("New lowest: " + timeInSeconds);
			}
		}
		
		System.out.println(highest);
		System.err.println("Lowest: " + lowest);
		System.err.println((lowest - highest));
		
		
	}
}

