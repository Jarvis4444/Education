// Template: Filtering a Variable-size String Collection 2.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example143App extends Object
{
	private static final String  CONSTANT_1 = "Attack 1 of 4 Minimum Interval In Seconds=22";
	private static final String HASH_REFERENCE = "969caad46c9299b6c3b76558fa192eb1";

	public static void main(String[] argStrings) throws Exception
	{
		ArrayList<String> weekdays = new ArrayList<String>();
		
		Scanner input = new Scanner(new File("data.txt"));
		
		while (true)
		{
			if (!input.hasNextLine())
			{
				break;
			}
		
			String string = input.nextLine();
		
			if (string.equals("end"))
			{
				break;
			}
		
			weekdays.add(string);
		}
		
		input.close();
		
		for (int i = 2; i < weekdays.size(); i += 2)
		{
			if (weekdays.get(i).startsWith("Tu"))
			{
				System.out.println(weekdays.get(i));
			}
		}
	}
}

