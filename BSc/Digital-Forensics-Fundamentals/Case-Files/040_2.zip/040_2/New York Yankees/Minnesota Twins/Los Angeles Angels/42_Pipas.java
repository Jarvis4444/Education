// Template: Filtering a numeric Array 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example9App extends Object
{
	private static final String  CONSTANT_1 = "Attack 4 of 4 Maximum Interval In Seconds=NjYyMw==";
	private static final String HASH_REFERENCE = "fe1407316f68a8622c24e024e328f7e7";

	public static void main(String[] argStrings) throws Exception
	{
		int[] numbersOfDays = {708, 193, 185, 459, 337, 230, 350, 190, 914};
		
		int sum = 0;
		
		for (int count = numbersOfDays.length - 1; count > 0; count--)
		{
			System.err.println("numberOfDays: " + numbersOfDays[count]);
		
			if (!(numbersOfDays[count] >= 322))
			{
				sum = sum + numbersOfDays[count];
			}
		}
		
		System.err.println("Total: " + sum);
		
	}
}

