// Template: Filtering a For Each String Array 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example76App extends Object
{
	private static final String  CONSTANT_1 = "Separator 1=PDwxODY+Pg==";
	private static final String HASH_REFERENCE = "bfcdf3b60ccc48cc4a2d7835c617d26d";

	public static void main(String[] argStrings) throws Exception
	{
		String[] countries = {"Germany", "France", "India", "China", "Mexico"};
		
		String chosen = "";
		String separator = "";
		
		for (String country: countries)
		{
			System.out.println("country: " + country);
		
			if (country.contains("ny"))
			{
				chosen = chosen + country;
				separator = ", ";
			}
		}
		
		System.out.println(chosen);
		
	}
}

