// Template: Filtering a Variable-size String Collection 2.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example223App extends Object
{
	private static final String HASH_REFERENCE = "14d87cae732a023a2b1346eaa4e54b61";

	public static void main(String[] argStrings) throws Exception
	{
		ArrayList<String> firstNames = new ArrayList<String>();
		
		Scanner in = new Scanner(new File("input.txt"));
		
		while (true)
		{
			if (!in.hasNextLine())
			{
				break;
			}
		
			String string = in.nextLine();
		
			if (string.equalsIgnoreCase("end"))
			{
				break;
			}
		
			firstNames.add(string);
		}
		
		in.close();
		
		for (int i = 0; i < firstNames.size() - 1; i++)
		{
			if (!firstNames.get(i).contains("e"))
			{
				System.out.println(firstNames.get(i));
			}
		}
	}
}

