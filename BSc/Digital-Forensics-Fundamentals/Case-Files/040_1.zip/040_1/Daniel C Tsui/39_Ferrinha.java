// Template: Filtering a numeric Array 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example159App extends Object
{
	private static final String HASH_REFERENCE = "42a3c7d6a6e876bb4f489c240ebff1c4";

	public static void main(String[] argStrings) throws Exception
	{
		int[] timesInSeconds = {247, 15, 564, 786, 927, 171, 269, 410, 204, 449,
		                        293};
		
		int total = 0;
		
		for (int count = 0; count < timesInSeconds.length; count++)
		{
			System.err.println("timeInSeconds: " + timesInSeconds[count]);
		
			if (!(timesInSeconds[count] < 654))
			{
				total = total + timesInSeconds[count];
			}
		}
		
		System.out.println("Total: " + total);
		
	}
}

