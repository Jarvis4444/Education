// Template: Filtering a Variable-size String Collection 1.txt

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Example202App extends Object
{
	private static final String HASH_REFERENCE = "11294447378d8aba9a05da50f6b1df4b";

	public static void main(String[] argStrings) throws Exception
	{
		ArrayList<String> firstNames = new ArrayList<String>();
		
		Scanner in = new Scanner(new File("data.txt"));
		
		while (in.hasNextLine())
		{
			firstNames.add(in.nextLine());
		}
		
		in.close();
		
		for (int i = 0; i < firstNames.size(); i++)
		{
			if (firstNames.get(i).contains("e"))
			{
				System.out.println(firstNames.get(i));
			}
		}
	}
}

